from Procedure import *
from utils import *
from dataloader import *
from register import dataset
import pickle

testDict: dict = dataset.testDict
users = list(testDict.keys())
results = {'precision': np.zeros(len(world.topks)),
            'recall': np.zeros(len(world.topks)),
            'ndcg': np.zeros(len(world.topks))}

with open('code/CF_recom_hybrid_filtered', 'rb') as f:
    CF_recom = pickle.load(f)
with open('code/rating_dict', 'rb') as f:
    rating_dict = pickle.load(f)
CF_groundTrue = rating_dict['groundTrue_list']

X = zip(CF_recom, CF_groundTrue)
pre_results = []
for x in X:
    pre_results.append(test_one_batch(x))
scale = float(100/len(users))
for result in pre_results:
    results['recall'] += result['recall']
    results['precision'] += result['precision']
    results['ndcg'] += result['ndcg']
results['recall'] /= float(len(users))
results['precision'] /= float(len(users))
results['ndcg'] /= float(len(users))