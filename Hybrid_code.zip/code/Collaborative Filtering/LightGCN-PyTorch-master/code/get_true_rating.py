import world
import utils
from world import cprint
import torch
import numpy as np
from tensorboardX import SummaryWriter
import time
import Procedure
from os.path import join
import pickle
import register
from register import dataset
import os

Recmodel = register.MODELS[world.model_name](world.config, dataset)
Recmodel = Recmodel.to(world.device)

#load the model
file = f"lgn-yelp2022-2-64.pth.tar"
weight_file = os.path.join(world.FILE_PATH,file)
Recmodel.load_state_dict(torch.load(weight_file, map_location=torch.device('cpu')))
testDict = dataset.testDict
users = list(testDict.keys())

#get the model outputs: reocmmendation lists and the ground truth interactions
u_batch_size = 100
max_K = 20
total_batch = len(users) // u_batch_size + 1
with torch.no_grad():
    users_list = []
    rating_list = []
    groundTrue_list = []
    for batch_users in utils.minibatch(users, batch_size=u_batch_size):
        allPos = dataset.getUserPosItems(batch_users)
        groundTrue = [testDict[u] for u in batch_users]
        batch_users_gpu = torch.Tensor(batch_users).long()
        batch_users_gpu = batch_users_gpu.to(world.device)

        rating = Recmodel.getUsersRating(batch_users_gpu)
        #rating = rating.cpu()
        exclude_index = []
        exclude_items = []
        for range_i, items in enumerate(allPos):
            exclude_index.extend([range_i] * len(items))
            exclude_items.extend(items)
        rating[exclude_index, exclude_items] = -(1<<10)
        _, rating_K = torch.topk(rating, k=max_K)
        rating = rating.cpu().numpy()
        del rating
        users_list.append(batch_users)
        rating_list.append(rating_K.cpu())
        groundTrue_list.append(groundTrue)

#dump the model's results in a pickle file
with open('rating_dict', 'wb') as f:
    rating_dict = {'users_list': users_list, 
                   'rating_list': rating_list,
                   'groundTrue_list': groundTrue_list}
    pickle.dump(rating_dict, f)