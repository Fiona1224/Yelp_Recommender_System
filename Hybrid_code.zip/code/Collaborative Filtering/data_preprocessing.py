import numpy as np
import pandas as pd
import json
import pickle
from sklearn.preprocessing import LabelEncoder
import tqdm

with open('reviews', 'rb') as f:
    reviews = pickle.load(f)

#stars from 3-5
reviews = reviews.loc[reviews['stars'] >= 3]
reviews = reviews[reviews['user_id'].map(reviews['user_id'].value_counts()) > 20]

#map ids to numbers
labelencoder = LabelEncoder()
reviews['user_id_remap'] = labelencoder.fit_transform(reviews['user_id'])
reviews['business_id_remap'] = labelencoder.fit_transform(reviews['business_id'])

business_mapping = {} #business_id_remap: business_id
for index, row in reviews.iterrows():
    if row['business_id_remap'] not in business_mapping.keys():
        business_mapping[row['business_id_remap']] = row['business_id']

ui_matrix = {}
for index, row in reviews.iterrows():
    if row['user_id_remap'] in ui_matrix.keys():
        if row['business_id_remap'] not in ui_matrix[row['user_id_remap']]:
            ui_matrix[row['user_id_remap']].append(row['business_id_remap'])
    else:
        ui_matrix[row['user_id_remap']] = [row['user_id_remap'], row['business_id_remap']]

ui_matrix_ordered = dict(sorted(ui_matrix.items()))

with open('warm_start_items', 'rb') as f:
    warm_start_items = pickle.load(f)

for line in ui_matrix_ordered.values():
    #train ratio: 0.5
    len_train = int((len(line) - 1) * 0.5)
    line_train = line[:len_train+1]
    line_test = line[len_train+1:]
    line_test = [x for x in line_test if business_mapping[x] in warm_start_items]
    if len(line_test) == 0:
        continue
    line_test = [line[0]] + line_test
    with open('train.txt','a') as f1:
        f1.write(" ".join(str(x) for x in line_train) + "\n")
    with open('test.txt', 'a') as f2:
        f2.write(" ".join(str(x) for x in line_test) + "\n")