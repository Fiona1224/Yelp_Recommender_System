import json
import pandas as pd
import pickle

review_file = open("yelp_academic_dataset_review.json")
review = []
for line in review_file:
    review.append(json.loads(line))

reviews = pd.DataFrame(review)
review_file.close()

with open('reviews', 'wb') as f:
    pickle.dump(reviews, f)